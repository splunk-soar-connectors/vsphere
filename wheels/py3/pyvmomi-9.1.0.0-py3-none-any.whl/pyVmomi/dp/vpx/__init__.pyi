# Copyright (c) 2006-2026 Broadcom. All Rights Reserved.
# The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.

# ******* WARNING - AUTO GENERATED CODE - DO NOT EDIT *******

from . import capability as capability
from . import dr as dr


class DiskAlreadyClaimedReason:
   pass

class InvalidProtectionReason:
   pass

class MigrationType:
   pass

class ProtectionStatusType:
   pass

class ProtectionSupportType:
   pass

class SnapshotType:
   pass

class SyncType:
   pass

class VSphereDataProtectionCapabilities:
   pass

class VSphereDataProtectionCapabilities90U1:
   pass

class VssBackupContext:
   pass

class VssBackupType:
   pass
