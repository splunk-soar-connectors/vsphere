# Copyright (c) 2006-2026 Broadcom. All Rights Reserved.
# The term "Broadcom" refers to Broadcom Inc. and/or its subsidiaries.

# ******* WARNING - AUTO GENERATED CODE - DO NOT EDIT *******

from pyVmomi.eam.issue import AgencyIssue


class CannotDeleteSoftware(VUMIssue):
   pass

class CannotStageSoftware(VUMIssue):
   pass


class VUMIssue(AgencyIssue):
   pass

class VUMUnavailable(VUMIssue):
   pass
