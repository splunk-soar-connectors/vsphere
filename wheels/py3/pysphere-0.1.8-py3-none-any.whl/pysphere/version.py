# Do not edit. Auto generated
version = (0, 1, 8)